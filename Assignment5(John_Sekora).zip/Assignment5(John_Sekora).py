# Assignment 5 (John Sekora)

# 1.) Create a text file called ToDo.txt
# Open the file to write to
ToDo = open("ToDo.txt", "w")
# Write the strings
ToDo.write("Clean House,low\n")
ToDo.write("Pay Bills,high\n")
# Save and close
ToDo.close()

# 2.) When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary.
# Open the file to read from
ToDo = open("ToDo.txt", "r")
# Create a dictionary
dic = {}
# Loop through the file, assign values to the dictionary
for line in ToDo:
    x = line.split(",")
    a = x[0]
    b = x[1]
    b = b.strip("\n")
    dic[a] = b
# Convert the dictionary to a list
lstTable = [dic]
# Display the results
print(lstTable)

# 3.) After you get a row of data stored in a Python dictionary, add the new “row” into a Python List object
# 4.) Display the contents of the List to the user.
# 5.) Allow the user to Add or Remove tasks from the list using numbered choices.
# 6.) Save the data from the table into the ToDo.txt file when the program exits.
while True:
    # Display choices
    print("Choose 1 to Add task")
    print("Choose 2 to Remove task")
    print("Choose 3 to Save all tasks to the Todo.txt file and exit!")
    # Prompt user input
    Choice = int(input("Please choose now: (1/2/3)"))
    # Add task
    if Choice == 1:
        # User inputs
        TaskNew = input("Enter a new Task: ")
        PriorityNew = input("Enter a new Priority: ")
        lstRowNew = [TaskNew, PriorityNew]
        # Add new row
        lstTable.append(lstRowNew)
        # Display results
        print("The following list remains: ", lstTable)
        continue
    elif Choice == 2:
        # Prmpt user input for integer requestion list element deletion
        intDel = int(input("Please enter list element to delete: <integer>"))
        # Delete list element
        lstTable.pop(intDel)
        # Display results
        print("The following list remains: ", lstTable)
        continue
    elif Choice == 3:
        # Convert list to string
        strTable = str(lstTable)
        # Write list to file
        ToDo.write(strTable)
        # Save and close file
        ToDo.close()
        print("Your data has been saved.")
        break
    else:
        print("Please try again.")
        continue
